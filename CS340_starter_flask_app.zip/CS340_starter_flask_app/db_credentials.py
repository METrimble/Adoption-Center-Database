host = 'classmysql.engr.oregonstate.edu'
user = 'cs340_trimblma'
passwd = '2675'
db = 'cs340_trimblma'