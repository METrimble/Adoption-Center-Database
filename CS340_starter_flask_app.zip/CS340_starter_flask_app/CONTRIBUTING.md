=== How to contribute to this Project? ====

If you are a student of CS340 or CS464 at an OSU class, you can send a pull request to make this starter code better.

=== What can I contribute to this Project? ====

You can help make the instructions for the project setup or usage easier.


