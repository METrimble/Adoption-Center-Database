--Data Manipulation for Adoption Center
--Employee
--Add Employee

--Update Emplopyee

--Show Employee Tables

---------------------------------------
--Animal
--Add Animal

--Delete Animal

--View bt name

--Filter by Species

--Show Animal Table

---------------------------------------
--Location
--Add Location

--Show Location Table

---------------------------------------
--Foster Parent
--Add Foster Parent 

--Show Foster Parent Table